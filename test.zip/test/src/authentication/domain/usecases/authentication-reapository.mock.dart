import 'package:course/src/authentication/domain/repositories/authentication-repository.dart';
import 'package:mockito/mockito.dart';

class MockAuthRepo extends Mock implements AuthenticationRepository {}
